import '/auth/firebase_auth/auth_util.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'o_t_p_verification_page_widget.dart' show OTPVerificationPageWidget;
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class OTPVerificationPageModel
    extends FlutterFlowModel<OTPVerificationPageWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for OTPAuthform widget.
  FocusNode? oTPAuthformFocusNode;
  TextEditingController? oTPAuthformTextController;
  String? Function(BuildContext, String?)? oTPAuthformTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    oTPAuthformFocusNode?.dispose();
    oTPAuthformTextController?.dispose();
  }
}
