import '/auth/firebase_auth/auth_util.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'login_phone_page_widget.dart' show LoginPhonePageWidget;
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class LoginPhonePageModel extends FlutterFlowModel<LoginPhonePageWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for PhoneNumberAuth widget.
  FocusNode? phoneNumberAuthFocusNode;
  TextEditingController? phoneNumberAuthTextController;
  String? Function(BuildContext, String?)?
      phoneNumberAuthTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    phoneNumberAuthFocusNode?.dispose();
    phoneNumberAuthTextController?.dispose();
  }
}
