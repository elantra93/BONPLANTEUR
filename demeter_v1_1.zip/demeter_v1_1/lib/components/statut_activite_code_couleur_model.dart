import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'statut_activite_code_couleur_widget.dart'
    show StatutActiviteCodeCouleurWidget;
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class StatutActiviteCodeCouleurModel
    extends FlutterFlowModel<StatutActiviteCodeCouleurWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
