import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import 'imagepicker1_widget.dart' show Imagepicker1Widget;
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Imagepicker1Model extends FlutterFlowModel<Imagepicker1Widget> {
  ///  State fields for stateful widgets in this component.

  bool isDataUploading_uploadDataJustif = false;
  List<FFUploadedFile> uploadedLocalFiles_uploadDataJustif = [];
  List<String> uploadedFileUrls_uploadDataJustif = [];

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
