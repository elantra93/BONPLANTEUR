import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import 'ajouter_collaborateur_page_widget.dart'
    show AjouterCollaborateurPageWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AjouterCollaborateurPageModel
    extends FlutterFlowModel<AjouterCollaborateurPageWidget> {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for Nom widget.
  FocusNode? nomFocusNode;
  TextEditingController? nomTextController;
  String? Function(BuildContext, String?)? nomTextControllerValidator;
  // State field(s) for prenoms widget.
  FocusNode? prenomsFocusNode;
  TextEditingController? prenomsTextController;
  String? Function(BuildContext, String?)? prenomsTextControllerValidator;
  // State field(s) for surnom widget.
  FocusNode? surnomFocusNode;
  TextEditingController? surnomTextController;
  String? Function(BuildContext, String?)? surnomTextControllerValidator;
  DateTime? datePicked1;
  // State field(s) for salaire widget.
  FocusNode? salaireFocusNode;
  TextEditingController? salaireTextController;
  String? Function(BuildContext, String?)? salaireTextControllerValidator;
  // State field(s) for contact widget.
  FocusNode? contactFocusNode;
  TextEditingController? contactTextController;
  String? Function(BuildContext, String?)? contactTextControllerValidator;
  DateTime? datePicked2;
  bool isDataUploading_uploadDataXab = false;
  FFUploadedFile uploadedLocalFile_uploadDataXab =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadDataXab = '';

  bool isDataUploading_uploadDataTgb = false;
  FFUploadedFile uploadedLocalFile_uploadDataTgb =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadDataTgb = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    nomFocusNode?.dispose();
    nomTextController?.dispose();

    prenomsFocusNode?.dispose();
    prenomsTextController?.dispose();

    surnomFocusNode?.dispose();
    surnomTextController?.dispose();

    salaireFocusNode?.dispose();
    salaireTextController?.dispose();

    contactFocusNode?.dispose();
    contactTextController?.dispose();
  }
}
