import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/imagepicker1_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'ajouter_depense_page_widget.dart' show AjouterDepensePageWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:provider/provider.dart';

class AjouterDepensePageModel
    extends FlutterFlowModel<AjouterDepensePageWidget> {
  ///  Local state fields for this page.

  bool justifcharge = true;

  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for exploitationdepense widget.
  String? exploitationdepenseValue;
  FormFieldController<String>? exploitationdepenseValueController;
  // State field(s) for parcelledepense widget.
  String? parcelledepenseValue;
  FormFieldController<String>? parcelledepenseValueController;
  // State field(s) for activitedepense widget.
  String? activitedepenseValue;
  FormFieldController<String>? activitedepenseValueController;
  // State field(s) for Categoriedepense widget.
  String? categoriedepenseValue;
  FormFieldController<String>? categoriedepenseValueController;
  // State field(s) for Montantdepense widget.
  FocusNode? montantdepenseFocusNode;
  TextEditingController? montantdepenseTextController;
  String? Function(BuildContext, String?)?
      montantdepenseTextControllerValidator;
  // State field(s) for Beneficiaire widget.
  FocusNode? beneficiaireFocusNode;
  TextEditingController? beneficiaireTextController;
  String? Function(BuildContext, String?)? beneficiaireTextControllerValidator;
  DateTime? datePicked;
  // State field(s) for Date widget.
  FocusNode? dateFocusNode;
  TextEditingController? dateTextController;
  late MaskTextInputFormatter dateMask;
  String? Function(BuildContext, String?)? dateTextControllerValidator;
  // State field(s) for libelleDepense widget.
  FocusNode? libelleDepenseFocusNode;
  TextEditingController? libelleDepenseTextController;
  String? Function(BuildContext, String?)?
      libelleDepenseTextControllerValidator;
  // State field(s) for CommentaireDepense widget.
  FocusNode? commentaireDepenseFocusNode;
  TextEditingController? commentaireDepenseTextController;
  String? Function(BuildContext, String?)?
      commentaireDepenseTextControllerValidator;
  // Model for Imagepicker1 component.
  late Imagepicker1Model imagepicker1Model;

  @override
  void initState(BuildContext context) {
    imagepicker1Model = createModel(context, () => Imagepicker1Model());
  }

  @override
  void dispose() {
    montantdepenseFocusNode?.dispose();
    montantdepenseTextController?.dispose();

    beneficiaireFocusNode?.dispose();
    beneficiaireTextController?.dispose();

    dateFocusNode?.dispose();
    dateTextController?.dispose();

    libelleDepenseFocusNode?.dispose();
    libelleDepenseTextController?.dispose();

    commentaireDepenseFocusNode?.dispose();
    commentaireDepenseTextController?.dispose();

    imagepicker1Model.dispose();
  }
}
