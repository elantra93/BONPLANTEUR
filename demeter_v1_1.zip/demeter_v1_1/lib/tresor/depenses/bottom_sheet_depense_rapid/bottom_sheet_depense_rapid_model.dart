import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/components/imagepicker1_widget.dart';
import '/components/text_field_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'bottom_sheet_depense_rapid_widget.dart'
    show BottomSheetDepenseRapidWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class BottomSheetDepenseRapidModel
    extends FlutterFlowModel<BottomSheetDepenseRapidWidget> {
  ///  Local state fields for this component.

  String? selectedCategorie;

  ///  State fields for stateful widgets in this component.

  // Model for Montant.
  late TextFieldModel montantModel;
  // State field(s) for DropdownCollaborateur widget.
  String? dropdownCollaborateurValue;
  FormFieldController<String>? dropdownCollaborateurValueController;
  // Model for NoteRapide.
  late TextFieldModel noteRapideModel;
  // State field(s) for DropDownActivite widget.
  List<String>? dropDownActiviteValue;
  FormFieldController<List<String>>? dropDownActiviteValueController;
  // Model for Imagepicker1 component.
  late Imagepicker1Model imagepicker1Model;
  bool isDataUploading_justifDepense = false;
  List<FFUploadedFile> uploadedLocalFiles_justifDepense = [];
  List<String> uploadedFileUrls_justifDepense = [];

  @override
  void initState(BuildContext context) {
    montantModel = createModel(context, () => TextFieldModel());
    noteRapideModel = createModel(context, () => TextFieldModel());
    imagepicker1Model = createModel(context, () => Imagepicker1Model());
  }

  @override
  void dispose() {
    montantModel.dispose();
    noteRapideModel.dispose();
    imagepicker1Model.dispose();
  }
}
