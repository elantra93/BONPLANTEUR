import '/backend/backend.dart';
import '/components/selecteur_exploitation_widget.dart';
import '/flutter_flow/flutter_flow_autocomplete_options_list.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/tresor/depenses/bottom_sheet_depense_rapid/bottom_sheet_depense_rapid_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'liste_depenses_widget.dart' show ListeDepensesWidget;
import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:text_search/text_search.dart';

class ListeDepensesModel extends FlutterFlowModel<ListeDepensesWidget> {
  ///  Local state fields for this page.

  bool fullpageview = true;

  bool searchactive = true;

  ///  State fields for stateful widgets in this page.

  // Model for SelecteurExploitation component.
  late SelecteurExploitationModel selecteurExploitationModel;
  // State field(s) for TextField widget.
  final textFieldKey = GlobalKey();
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? textFieldSelectedOption;
  String? Function(BuildContext, String?)? textControllerValidator;
  List<DepensesRecord> simpleSearchResults = [];

  @override
  void initState(BuildContext context) {
    selecteurExploitationModel =
        createModel(context, () => SelecteurExploitationModel());
  }

  @override
  void dispose() {
    selecteurExploitationModel.dispose();
    textFieldFocusNode?.dispose();
  }
}
