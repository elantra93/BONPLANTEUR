import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import '/index.dart';
import 'modifier_materiel_widget.dart' show ModifierMaterielWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ModifierMaterielModel extends FlutterFlowModel<ModifierMaterielWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for NomMateriel widget.
  FocusNode? nomMaterielFocusNode;
  TextEditingController? nomMaterielTextController;
  String? Function(BuildContext, String?)? nomMaterielTextControllerValidator;
  // State field(s) for Exploitation widget.
  String? exploitationValue;
  FormFieldController<String>? exploitationValueController;
  // State field(s) for TypeMateriel widget.
  String? typeMaterielValue;
  FormFieldController<String>? typeMaterielValueController;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    nomMaterielFocusNode?.dispose();
    nomMaterielTextController?.dispose();
  }
}
