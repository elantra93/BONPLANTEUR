import '/backend/backend.dart';
import '/components/selecteur_exploitation_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'liste_activites_page_widget.dart' show ListeActivitesPageWidget;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ListeActivitesPageModel
    extends FlutterFlowModel<ListeActivitesPageWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for SelecteurExploitation component.
  late SelecteurExploitationModel selecteurExploitationModel;

  @override
  void initState(BuildContext context) {
    selecteurExploitationModel =
        createModel(context, () => SelecteurExploitationModel());
  }

  @override
  void dispose() {
    selecteurExploitationModel.dispose();
  }
}
