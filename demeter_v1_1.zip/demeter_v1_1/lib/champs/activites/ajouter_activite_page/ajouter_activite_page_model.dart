import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/date_picker_texfield_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 'ajouter_activite_page_widget.dart' show AjouterActivitePageWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class AjouterActivitePageModel
    extends FlutterFlowModel<AjouterActivitePageWidget> {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for DropDown widget.
  String? dropDownValue;
  FormFieldController<String>? dropDownValueController;
  List<ParcellesRecord>? dropDownPreviousSnapshot;
  // State field(s) for Libelle_activite widget.
  FocusNode? libelleActiviteFocusNode;
  TextEditingController? libelleActiviteTextController;
  String? Function(BuildContext, String?)?
      libelleActiviteTextControllerValidator;
  // State field(s) for consignes widget.
  FocusNode? consignesFocusNode;
  TextEditingController? consignesTextController;
  String? Function(BuildContext, String?)? consignesTextControllerValidator;
  // State field(s) for categorie widget.
  String? categorieValue;
  FormFieldController<String>? categorieValueController;
  // Model for DatePickerTexfield component.
  late DatePickerTexfieldModel datePickerTexfieldModel;
  // State field(s) for affectation widget.
  String? affectationValue;
  FormFieldController<String>? affectationValueController;

  @override
  void initState(BuildContext context) {
    datePickerTexfieldModel =
        createModel(context, () => DatePickerTexfieldModel());
  }

  @override
  void dispose() {
    libelleActiviteFocusNode?.dispose();
    libelleActiviteTextController?.dispose();

    consignesFocusNode?.dispose();
    consignesTextController?.dispose();

    datePickerTexfieldModel.dispose();
  }
}
