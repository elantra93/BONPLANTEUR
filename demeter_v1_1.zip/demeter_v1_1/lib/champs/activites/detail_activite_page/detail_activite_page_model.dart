import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import 'detail_activite_page_widget.dart' show DetailActivitePageWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DetailActivitePageModel
    extends FlutterFlowModel<DetailActivitePageWidget> {
  ///  State fields for stateful widgets in this page.

  bool isDataUploading_preuvesActivite = false;
  FFUploadedFile uploadedLocalFile_preuvesActivite =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_preuvesActivite = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
