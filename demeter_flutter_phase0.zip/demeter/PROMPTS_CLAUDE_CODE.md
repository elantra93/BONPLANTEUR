# PROMPTS_CLAUDE_CODE.md — DEMETER

Suite de prompts **prêts-à-coller**, phase par phase. Lire `CLAUDE.md` au début de chaque session.
**Ne pas démarrer une phase tant que la gate précédente n'est pas verte.** Tests sur l'émulateur Firebase.
Sessions VPS dans `tmux`/`screen`. Reprise : `claude -c` / `claude --continue` · `claude -r` / `claude --resume`.

---

## Phase 0 — Bootstrap, thème & constantes
```
Lis CLAUDE.md. Initialise le projet Flutter DEMETER (web + Android), Material 3.
1. Dépendances : flutter_riverpod, go_router, freezed+build_runner, json_serializable, firebase (core/firestore/auth/storage),
   google_fonts, table_calendar, intl, image_picker, flutter_image_compress.
2. Arbo : lib/core (constants, theme, rbac, router, utils, services), lib/features/<module>, lib/shared.
3. firestore_collections.dart : UNE constante par collection (dont la NOUVELLE `campagnes`). Aucune chaîne ailleurs.
4. Design system §3 de CLAUDE.md : couleurs (accent = "Or maïs" #C68A1F), Poppins+Inter, espacements, statuts, thèmes clair/sombre.
5. Widgets partagés + page vitrine (palette, typo, statuts, boutons, champs) en clair et sombre.
```
**Gate 0 :** la vitrine s'affiche, bascule clair/sombre OK, aucune chaîne de collection hors constantes, `flutter analyze` propre.

---

## Phase 1 — Firebase + Émulateur + Auth téléphone
```
Lis CLAUDE.md (NN 5, 8, 9). Configure firebase_core + Emulator Suite (Auth/Firestore/Storage, flag prod/émulateur).
phoneToEmail À L'IDENTIQUE de DEMETER1 (225 + 10 chiffres + @demeter-app.com, masque 10 chiffres).
Écran de connexion (hero logo_hero_ble + tagline), AuthRepository (signIn/signOut/currentUser), création/maj doc USERS.
Pas de reset MDP client (Cloud Function en Phase 12).
```
**Gate 1 :** connexion d'un compte test sur l'émulateur, doc USERS créé, format email strictement identique à DEMETER1.

---

## Phase 2 — Modèles, repositories & isolation tenant
```
Lis CLAUDE.md (NN 1,2,4 ; §4 modèle). Modèles freezed+json pour toutes les collections, Y COMPRIS la nouvelle `campagnes`
(exploitation_ref, parcelle_refs[], culture, rendement_attendu_ha, date_debut, date_fin, prix_vente_cible,
revenu_attendu, budget?, statut, is_active). Parcelle = identité physique seule (culture dépréciée, lecture seule).
BaseRepository : filtre is_active==true sur les listes ; filtre exploitation_ref sur TOUTE requête ; pas de delete (soft delete).
Tests émulateur : impossible de lister sans exploitation_ref ; soft delete masque l'élément.
```
**Gate 2 :** aucune lecture métier sans exploitation_ref, aucun hard delete, tests verts.

---

## Phase 3 — RBAC (8 rôles) + gardes de routes
```
Lis CLAUDE.md (NN 6,7 ; §1 personas). RbacService sur la LISTE de rôles (hasRole/hasAnyRole/can), combinaisons interdites.
Mappe les personas : Entrepreneur=ADMIN+CHEF_EXPLOITATION, Chef d'équipe=CHEF_PARCELLE, Ouvrier=OUVRIER ; hiérarchie superieur_id.
go_router redirect (auth + rôle), écran "Accès non autorisé", widget RequirePermission. Démo d'un écran rendu selon le rôle.
```
**Gate 3 :** un OUVRIER ne voit ni création ni validation ; routes protégées ; combinaisons interdites refusées.

---

## Phase 4 — Règles Firestore & Storage
```
Lis CLAUDE.md (NN 3,4,9). Pour CHAQUE collection métier (dont `campagnes`) : allow create, read, update si auth +
appartenance exploitation + rôle. JAMAIS allow write. Aucune règle delete. Vérifie l'appartenance via exploitation_ref.
storage.rules : upload restreint par exploitation, types/tailles limités. Tests @firebase/rules-unit-testing
(isolation inter-exploitation, interdiction de delete, write non autorisé rejeté).
```
**Gate 4 :** aucun `allow write`, tous les tests d'isolation et d'interdiction de delete passent.

---

## Phase 5 — Shell & dashboard (par persona)
```
Lis CLAUDE.md §3.1 (structure dashboard à respecter à la lettre).
1. Sélecteur d'exploitation en haut (recharge la page).
2. 4 tuiles 2x2 : Consommation budget (sac "FCFA", jauge vert→or→rouge — MASQUÉE pour l'ouvrier), Planning,
   Alertes (compteur), Suivi stocks (compteur). Chaque tuile ouvre sa page.
3. Liste des 5 activités récentes avec statut (Fait/Vérifié/Rejeté/En retard).
4. Bottom nav 3 onglets, grosses icônes minimalistes, TITRE seulement sur l'onglet actif :
   Accueil (maison), Exploitations (moulin), Trésor (sac "FCFA").
Variantes : Entrepreneur (tout), Chef (ses parcelles, sans revenus), Ouvrier (Planning + Mes revenus uniquement).
```
**Gate 5 :** dashboard conforme au croquis, tuiles/nav adaptées au persona, budget masqué pour l'ouvrier.

---

## Phase 6 — Exploitations, Parcelles & 🆕 Campagnes
```
Lis CLAUDE.md §4-5. CRUD soft-delete :
1. Exploitations (filtrées is_active + appartenance), Parcelles (identité physique : superficie_ha, localisation).
2. CAMPAGNES : lancement sur 1+ parcelles, saisie culture, rendement_attendu_ha, dates, prix_vente_cible.
   Calcule revenu_attendu = rendement_attendu_ha × superficie totale × prix_vente_cible.
   budget optionnel ; si vide → 70% du revenu_attendu (afficher l'estimation).
3. Tout filtré par exploitation_ref. Sélecteurs réutilisables (exploitation, parcelle, campagne active).
```
**Gate 6 :** création d'une campagne sur plusieurs parcelles ; revenu_attendu et budget (ou estimation 70%) corrects.

---

## Phase 7 — Activités (workflow + photos + ressources)
```
Lis CLAUDE.md §5 (cycle de vie). 
1. Liste filtrée par statut + RBAC (l'ouvrier ne voit que ses activités affectées).
2. Création : type, date_prevue, campagne_ref (impacte la campagne), parcelle(s), affectation à des ouvriers (collaborateurs).
3. Passage en "Fait" par le chef : EXIGE >=1 photo (caméra en Phase 11, galerie pour l'instant) + ressources_consommees
   (qui créent des mouvements consommation_stock décrémentant le stock — SANS approbation) + main_oeuvre_externe optionnelle (= dépense).
4. "Fait" -> "Vérifié"/"Rejeté" par le PATRON SEUL (consulte les photos). En retard = date_prevue dépassée non faite.
Code couleur de statut conforme §3.2.
```
**Gate 7 :** cycle planifiée→fait(photos+ressources obligatoires)→vérifié/rejeté ; vérification réservée au patron ; stock décrémenté.

---

## Phase 8 — 📅 Calendrier
```
Lis CLAUDE.md §7. table_calendar (mois+semaine), AUCUNE nouvelle collection. Source = activites
(date_prevue=prévu, date_execution=réalisé) + échéances (retards, dates de fin de campagne/récoltes).
Marqueurs colorés par statut + légende. "+" pour planifier. Filtré par exploitation_ref ET par RBAC.
```
**Gate 8 :** prévu/réalisé/échéances corrects, filtrés par tenant et rôle, jour→détail OK.

---

## Phase 9 — Trésor (finances + moteur de calcul)
```
Lis CLAUDE.md §5 (moteur financier) + §3.1 (vues role-gated).
1. Dépenses : type DIRECTE (activité/parcelle) ou GÉNÉRALE (frais généraux). 
   Frais généraux ventilés AU PRORATA de la superficie sur les parcelles/exploitations bénéficiaires.
2. Approbation : SEULES les sorties d'argent soumises par le chef → approuvées/rejetées par le patron.
3. Ventes / revenus (collection revenus). Stocks (seuils d'alerte). Récoltes (réalisé vs attendu de la campagne).
4. Vues : Entrepreneur = tout (budget, dépenses, revenus, reste) ; Chef = consommation de SES parcelles sans revenus ;
   Ouvrier = SES revenus (journées/salaire). taux_consommation = dépenses/budget (campagne et parcelle).
```
**Gate 9 :** ventilation prorata correcte ; approbation des sorties d'argent par le patron ; vues conformes au persona.

---

## Phase 10 — Personnel (RH) & invitations
```
Lis CLAUDE.md. Équipe par exploitation, fiche collaborateur (nom, naissance, début, salaire, contacts, photo CNI/collaborateur).
user_id optionnel (lien vers compte si connecté). Invitations : code DEM-XXXXXX, expiration, statut ; membership aligné sur la liste de rôles.
```
**Gate 10 :** ajout collaborateur + invitation avec code/expiration ; lien compte optionnel fonctionnel.

---

## Phase 11 — Offline, caméra & compression
```
Lis CLAUDE.md. Drift : cache local + file de synchronisation (écritures rejouées à la reconnexion), bannière hors-ligne.
Composant image : caméra + galerie, compression avant upload, progression en français. Tout message en français.
```
**Gate 11 :** activité/dépense saisie hors-ligne puis synchro ; photo caméra compressée+uploadée ; zéro anglais.

---

## Phase 12 — Build & déploiement VPS
```
Lis CLAUDE.md §8. Cloud Functions (reset MDP admin + invitations). Web : flutter build web --release, nginx (statique,
fallback SPA, gzip/brotli, HTTP/2), SSL certbot. APK : flutter build apk --release. Firebase : domaine VPS dans Authorized
domains, règles Storage prod. Checklist bascule émulateur→prod, sauvegardes, variables d'env.
```
**Gate 12 :** web en HTTPS sur le domaine, APK installable et connecté, reset MDP admin OK, aucune écriture de test en prod.

---

### Rappel — gates bloquantes
En cas de doute sur une règle 🔒 : s'arrêter et demander. Ne jamais contourner (write interdit, hard delete interdit,
phoneToEmail à l'identique, filtrage exploitation_ref, vérification activité réservée au patron, émulateur en dev).
