# DEMETER

> **Le logiciel métier bâti pour nos champs.**
> SaaS de gestion d'exploitation agricole (Côte d'Ivoire) — Flutter + Firebase.

Ce dépôt contient la **fondation** de l'application (Phase 0) : architecture, design
system dérivé des logos, RBAC, constantes, widgets partagés et une page vitrine.
Les modules métier se construisent ensuite phase par phase — voir
[`PROMPTS_CLAUDE_CODE.md`](PROMPTS_CLAUDE_CODE.md). Les règles à ne jamais enfreindre
sont dans [`CLAUDE.md`](CLAUDE.md).

---

## Démarrer

> Prérequis : Flutter ≥ 3.22 installé (`flutter --version`).

```bash
flutter pub get
flutter run -d chrome      # web (vitrine du design system)
# ou : flutter run          # appareil / émulateur Android
```

La Phase 0 **ne nécessite pas Firebase** : l'app affiche la vitrine du design
system (palette, typographie, statuts, boutons, champs) en mode clair et sombre
(bouton en haut à droite).

> ⚠️ Comme le projet a été écrit sans compilation, un `flutter pub get` peut
> demander d'ajuster une ou deux versions de packages dans `pubspec.yaml`.
> Lancez `flutter analyze` pour vérifier.

---

## Ce qui est déjà en place (Phase 0)

| Élément | Fichier |
|---------|---------|
| Noms de collections centralisés 🔒 | `lib/core/constants/firestore_collections.dart` |
| Palette de marque (logos) | `lib/core/theme/app_colors.dart` |
| Typographie Poppins + Inter | `lib/core/theme/app_typography.dart` |
| Espacements / rayons | `lib/core/theme/app_spacing.dart` |
| Couleurs de statut (couleur+icône+libellé) | `lib/core/theme/status_palette.dart` |
| Thèmes clair & sombre (M3) | `lib/core/theme/app_theme.dart` |
| 8 rôles RBAC | `lib/core/rbac/app_role.dart` |
| Service RBAC (combinaisons, `can()`) | `lib/core/rbac/rbac_service.dart` |
| `phoneToEmail` 🔒 | `lib/core/utils/phone_to_email.dart` |
| Routeur (squelette + garde à venir) | `lib/core/router/app_router.dart` |
| Widgets partagés | `lib/shared/widgets/` |
| Vitrine | `lib/features/showcase/showcase_page.dart` |
| Logos | `assets/brand/` |

---

## Étapes suivantes

1. **Phase 1** — Firebase + émulateur + auth téléphone (voir `PROMPTS_CLAUDE_CODE.md`).
   Ajouter `lib/firebase_options.dart` et les fichiers de config (non committés).
2. Puis modèles, RBAC dans l'UI, règles Firestore, modules métier, **calendrier**,
   offline, et déploiement VPS.

## Règles à ne jamais enfreindre (extrait de CLAUDE.md)

- Noms de collections **uniquement** via `FirestoreCollections`.
- Filtrer **chaque** requête métier par `exploitation_ref`.
- Règles Firestore : `create, read, update` — **jamais `write`** (qui inclut `delete`).
- **Soft delete** via `is_active` ; aucun hard delete.
- `phoneToEmail` strictement identique à DEMETER1.
- Développement **sur l'émulateur Firebase**, jamais sur la prod partagée.

---

## Licence

Projet privé — Demeter / elantra93.
