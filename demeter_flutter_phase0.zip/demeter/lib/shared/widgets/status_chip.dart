import 'package:flutter/material.dart';

import '../../core/theme/status_palette.dart';

/// Badge de statut : couleur + icône + libellé (jamais la couleur seule).
/// Voir §3.2 de CLAUDE.md.
class StatusChip extends StatelessWidget {
  const StatusChip(this.status, {super.key});

  final StatusKind status;

  @override
  Widget build(BuildContext context) {
    final color = status.color;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withOpacity(0.45)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(status.icon, size: 15, color: color),
          const SizedBox(width: 6),
          Text(
            status.label,
            style: TextStyle(
                color: color, fontSize: 12.5, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}
