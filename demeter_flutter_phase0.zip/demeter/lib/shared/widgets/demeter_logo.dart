import 'package:flutter/material.dart';

/// Affiche le bon logo selon le thème (clair → brun, sombre → version crème
/// sur espresso). Voir §3.5 de CLAUDE.md.
class DemeterLogo extends StatelessWidget {
  const DemeterLogo({super.key, this.height = 48, this.greenVariant = false});

  final double height;

  /// Utilise la variante verte (sur fond clair) plutôt que la brune.
  final bool greenVariant;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final asset = isDark
        ? 'assets/brand/logo_espresso.png'
        : (greenVariant
            ? 'assets/brand/logo_vert.png'
            : 'assets/brand/logo_brun.png');

    return Image.asset(asset, height: height, fit: BoxFit.contain);
  }
}
