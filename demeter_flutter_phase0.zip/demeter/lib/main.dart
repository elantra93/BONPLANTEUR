import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app.dart';

/// Point d'entrée.
///
/// Phase 0 : on ne touche pas encore à Firebase (initialisation + émulateur
/// arrivent en Phase 1, voir PROMPTS_CLAUDE_CODE.md). L'app affiche pour l'instant
/// la vitrine du design system.
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ProviderScope(child: DemeterApp()));
}
