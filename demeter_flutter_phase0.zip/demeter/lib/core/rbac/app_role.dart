/// Les 8 rôles RBAC de DEMETER. Voir non-négociable n°6 de CLAUDE.md.
///
/// IMPORTANT : un utilisateur porte une LISTE de rôles (USERS.roles: List<String>),
/// pas un rôle unique.
enum AppRole {
  admin('ADMIN'),
  chefExploitation('CHEF_EXPLOITATION'),
  chefParcelle('CHEF_PARCELLE'),
  technicien('TECHNICIEN'),
  ouvrier('OUVRIER'),
  comptable('COMPTABLE'),
  signataireDepenses('SIGNATAIRE_DEPENSES'),
  lecteur('LECTEUR');

  const AppRole(this.code);

  /// Valeur stockée dans Firestore (USERS.roles).
  final String code;

  static AppRole? fromCode(String code) {
    for (final r in AppRole.values) {
      if (r.code == code) return r;
    }
    return null;
  }

  String get label => switch (this) {
        AppRole.admin => 'Administrateur',
        AppRole.chefExploitation => "Chef d'exploitation",
        AppRole.chefParcelle => 'Chef de parcelle',
        AppRole.technicien => 'Technicien',
        AppRole.ouvrier => 'Ouvrier',
        AppRole.comptable => 'Comptable',
        AppRole.signataireDepenses => 'Signataire des dépenses',
        AppRole.lecteur => 'Lecteur',
      };
}
