import 'app_role.dart';

/// Actions de l'application soumises à autorisation.
enum AppAction {
  gererUtilisateurs,
  creerExploitation,
  creerParcelle,
  creerActivite,
  validerActivite,
  saisirDepense,
  validerDepense,
  gererStock,
  gererPersonnel,
  consulter, // lecture seule, ouverte à tous les rôles connectés
}

/// Service RBAC : raisonne sur la LISTE de rôles d'un utilisateur.
/// Voir non-négociable n°6 de CLAUDE.md. À brancher dans l'UI en Phase 3.
class RbacService {
  const RbacService(this.roles);

  /// Rôles bruts de l'utilisateur (USERS.roles).
  final List<AppRole> roles;

  factory RbacService.fromCodes(List<String> codes) => RbacService(
        codes
            .map(AppRole.fromCode)
            .whereType<AppRole>()
            .toList(growable: false),
      );

  bool hasRole(AppRole role) => roles.contains(role);
  bool hasAnyRole(Iterable<AppRole> any) => any.any(roles.contains);
  bool get isAdmin => hasRole(AppRole.admin);

  /// Combinaisons de rôles INTERDITES (exemples du PRD ; à compléter).
  static const List<Set<AppRole>> forbiddenCombinations = [
    {AppRole.ouvrier, AppRole.admin},
  ];

  /// Vérifie qu'un ensemble de rôles est cohérent (aucune combinaison interdite).
  static bool isValidCombination(List<AppRole> candidate) {
    final set = candidate.toSet();
    for (final forbidden in forbiddenCombinations) {
      if (forbidden.every(set.contains)) return false;
    }
    return true;
  }

  /// Cœur de l'autorisation : qui peut faire quoi.
  bool can(AppAction action) {
    if (isAdmin) return true; // l'admin peut tout
    return switch (action) {
      AppAction.gererUtilisateurs => false,
      AppAction.creerExploitation => hasRole(AppRole.chefExploitation),
      AppAction.creerParcelle =>
        hasAnyRole({AppRole.chefExploitation, AppRole.chefParcelle}),
      AppAction.creerActivite => hasAnyRole(
          {AppRole.chefExploitation, AppRole.chefParcelle, AppRole.technicien}),
      AppAction.validerActivite =>
        hasAnyRole({AppRole.chefExploitation, AppRole.chefParcelle}),
      AppAction.saisirDepense =>
        hasAnyRole({AppRole.comptable, AppRole.chefExploitation}),
      AppAction.validerDepense =>
        hasAnyRole({AppRole.signataireDepenses, AppRole.chefExploitation}),
      AppAction.gererStock =>
        hasAnyRole({AppRole.chefExploitation, AppRole.chefParcelle, AppRole.technicien}),
      AppAction.gererPersonnel =>
        hasAnyRole({AppRole.chefExploitation, AppRole.chefParcelle}),
      AppAction.consulter => roles.isNotEmpty, // tout rôle connecté peut lire
    };
  }
}
