/// 🔒 Conversion téléphone → email synthétique. Non-négociable n°5 de CLAUDE.md.
///
/// Schéma : `225` + 10 chiffres locaux + `@demeter-app.com`.
/// Le masque de saisie impose 10 chiffres, donc aucune branche de normalisation
/// défensive n'est nécessaire ici.
///
/// ⚠️ AVANT MISE EN PROD : vérifier au caractère près que cette sortie est
/// STRICTEMENT identique à celle de la fonction `phoneToEmail` de DEMETER1.
/// La moindre divergence casse la connexion des comptes existants.
String phoneToEmail(String tenDigitsPhone) {
  return '225$tenDigitsPhone@demeter-app.com';
}

/// Validation du numéro saisi (exactement 10 chiffres).
bool isValidIvorianLocalNumber(String input) {
  return RegExp(r'^\d{10}$').hasMatch(input);
}
