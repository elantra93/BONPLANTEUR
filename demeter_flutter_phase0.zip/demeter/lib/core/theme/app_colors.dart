import 'package:flutter/material.dart';

/// Palette de marque DEMETER — extraite des logos officiels.
///
/// Vert Demeter (logo vert) · Brun terre (logo brun) · Brun espresso (logo sombre)
/// · Or maïs (champ doré). Voir §3.2 de CLAUDE.md.
abstract final class AppColors {
  const AppColors._();

  // — Couleurs de marque —
  static const Color greenDemeter = Color(0xFF265C2F); // primaire
  static const Color brownEarth = Color(0xFF502E15); // secondaire / titres
  static const Color espresso = Color(0xFF24160E); // surfaces sombres
  static const Color wheatGold = Color(0xFFC68A1F); // accent "Or maïs" (parcimonieux)

  // — Mode clair —
  static const Color lightBackground = Color(0xFFFFFFFF);
  static const Color lightSurface = Color(0xFFFAF8F4); // crème
  static const Color lightSurfaceVariant = Color(0xFFF4F1EA);
  static const Color lightPrimaryContainer = Color(0xFFE2EDE5);
  static const Color lightSecondaryContainer = Color(0xFFEADFD3);
  static const Color lightTertiaryContainer = Color(0xFFF6E7C8);
  static const Color lightOutline = Color(0xFFC9C0B2);
  static const Color lightOutlineVariant = Color(0xFFE5DFD5);
  static const Color lightTextPrimary = Color(0xFF1F140C); // espresso adouci
  static const Color lightTextSecondary = Color(0xFF6B5E52);

  // — Mode sombre (basé sur le logo espresso) —
  static const Color darkBackground = Color(0xFF24160E);
  static const Color darkSurface = Color(0xFF2E211A);
  static const Color darkSurfaceVariant = Color(0xFF3A2C22);
  static const Color darkPrimary = Color(0xFF5FAE6B); // vert éclairci
  static const Color darkAccent = Color(0xFFE0AF21);
  static const Color darkTextPrimary = Color(0xFFF5EFE6); // crème
  static const Color darkTextSecondary = Color(0xFFB7A99B);
  static const Color darkOutline = Color(0xFF5A4A3C);

  // — Sémantique —
  static const Color error = Color(0xFFB23A2E); // rouge terre
}
