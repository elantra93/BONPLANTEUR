import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Typographie DEMETER : Poppins (titres / marque) + Inter (corps, formulaires,
/// montants). Voir §3.3 de CLAUDE.md.
///
/// Note prod : pour un usage hors-ligne fiable, embarquer les polices en assets
/// plutôt que via google_fonts (téléchargement runtime). À traiter en Phase 11.
abstract final class AppTypography {
  const AppTypography._();

  static TextTheme textTheme(ColorScheme c) {
    final onSurface = c.onSurface;
    final onSurfaceVariant = c.onSurfaceVariant;

    return TextTheme(
      // — Display / titres : Poppins —
      displayLarge: GoogleFonts.poppins(
        fontSize: 32, fontWeight: FontWeight.w700, color: onSurface, height: 1.15),
      displayMedium: GoogleFonts.poppins(
        fontSize: 28, fontWeight: FontWeight.w700, color: onSurface, height: 1.2),
      headlineMedium: GoogleFonts.poppins(
        fontSize: 24, fontWeight: FontWeight.w600, color: onSurface),
      titleLarge: GoogleFonts.poppins(
        fontSize: 20, fontWeight: FontWeight.w600, color: onSurface),
      titleMedium: GoogleFonts.poppins(
        fontSize: 16, fontWeight: FontWeight.w600, color: onSurface),

      // — Corps / UI : Inter —
      bodyLarge: GoogleFonts.inter(
        fontSize: 16, fontWeight: FontWeight.w400, color: onSurface, height: 1.4),
      bodyMedium: GoogleFonts.inter(
        fontSize: 15, fontWeight: FontWeight.w400, color: onSurface, height: 1.4),
      bodySmall: GoogleFonts.inter(
        fontSize: 13, fontWeight: FontWeight.w400, color: onSurfaceVariant),
      labelLarge: GoogleFonts.inter(
        fontSize: 15, fontWeight: FontWeight.w600, color: onSurface),
      labelMedium: GoogleFonts.inter(
        fontSize: 13, fontWeight: FontWeight.w500, color: onSurfaceVariant),
      labelSmall: GoogleFonts.inter(
        fontSize: 12, fontWeight: FontWeight.w500, color: onSurfaceVariant),
    );
  }

  /// Style pour les montants (FCFA) : chiffres tabulaires alignés.
  static TextStyle money(ColorScheme c, {double size = 16}) => GoogleFonts.inter(
        fontSize: size,
        fontWeight: FontWeight.w600,
        color: c.onSurface,
        fontFeatures: const [FontFeature.tabularFigures()],
      );
}
