import 'package:flutter/material.dart';

import 'app_colors.dart';
import 'app_spacing.dart';
import 'app_typography.dart';

/// Construit les thèmes clair et sombre de DEMETER (Material 3).
/// On part d'un ColorScheme.fromSeed (robuste entre versions de Flutter) puis on
/// surcharge les couleurs clés avec les tokens de marque.
abstract final class AppTheme {
  const AppTheme._();

  static ThemeData get light => _build(Brightness.light);
  static ThemeData get dark => _build(Brightness.dark);

  static ThemeData _build(Brightness brightness) {
    final isDark = brightness == Brightness.dark;

    final base = ColorScheme.fromSeed(
      seedColor: AppColors.greenDemeter,
      brightness: brightness,
    );

    final scheme = isDark
        ? base.copyWith(
            primary: AppColors.darkPrimary,
            onPrimary: AppColors.espresso,
            secondary: AppColors.wheatGold,
            tertiary: AppColors.darkAccent,
            surface: AppColors.darkSurface,
            onSurface: AppColors.darkTextPrimary,
            onSurfaceVariant: AppColors.darkTextSecondary,
            outline: AppColors.darkOutline,
            error: AppColors.error,
          )
        : base.copyWith(
            primary: AppColors.greenDemeter,
            onPrimary: Colors.white,
            primaryContainer: AppColors.lightPrimaryContainer,
            onPrimaryContainer: const Color(0xFF0E2A14),
            secondary: AppColors.brownEarth,
            onSecondary: Colors.white,
            secondaryContainer: AppColors.lightSecondaryContainer,
            onSecondaryContainer: const Color(0xFF2A1707),
            tertiary: AppColors.wheatGold,
            onTertiary: Colors.white,
            tertiaryContainer: AppColors.lightTertiaryContainer,
            onTertiaryContainer: const Color(0xFF4A3208),
            surface: AppColors.lightSurface,
            onSurface: AppColors.lightTextPrimary,
            onSurfaceVariant: AppColors.lightTextSecondary,
            outline: AppColors.lightOutline,
            outlineVariant: AppColors.lightOutlineVariant,
            error: AppColors.error,
          );

    final textTheme = AppTypography.textTheme(scheme);

    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor:
          isDark ? AppColors.darkBackground : AppColors.lightBackground,
      textTheme: textTheme,

      appBarTheme: AppBarTheme(
        backgroundColor:
            isDark ? AppColors.darkBackground : AppColors.lightBackground,
        foregroundColor: scheme.onSurface,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: textTheme.titleLarge,
      ),

      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(AppSizes.minTouchTarget),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppRadius.sm),
          ),
          textStyle: textTheme.labelLarge,
        ),
      ),

      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size.fromHeight(AppSizes.minTouchTarget),
          side: BorderSide(color: scheme.outline),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppRadius.sm),
          ),
          textStyle: textTheme.labelLarge,
        ),
      ),

      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: isDark
            ? AppColors.darkSurfaceVariant
            : AppColors.lightSurfaceVariant,
        contentPadding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.lg, vertical: AppSpacing.md),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.sm),
          borderSide: BorderSide(color: scheme.outlineVariant),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.sm),
          borderSide: BorderSide(color: scheme.outlineVariant),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.sm),
          borderSide: BorderSide(color: scheme.primary, width: 2),
        ),
        labelStyle: textTheme.labelMedium,
      ),

      chipTheme: ChipThemeData(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.pill),
        ),
      ),

      dividerTheme: DividerThemeData(color: scheme.outlineVariant, space: 1),
    );
  }
}
