import 'package:flutter/material.dart';

/// Statuts métier (activités / dépenses). Voir §3.2 de CLAUDE.md.
///
/// Règle d'accessibilité : on affiche TOUJOURS couleur + icône + libellé,
/// jamais la couleur seule.
enum StatusKind {
  brouillon,
  planifie,
  enCours,
  termine,
  valide,
  rejete,
  echeance,
}

extension StatusKindX on StatusKind {
  Color get color => switch (this) {
        StatusKind.brouillon => const Color(0xFF9E9385),
        StatusKind.planifie => const Color(0xFFC68A1F),
        StatusKind.enCours => const Color(0xFF2F6FB0),
        StatusKind.termine => const Color(0xFF6BAE3A),
        StatusKind.valide => const Color(0xFF265C2F),
        StatusKind.rejete => const Color(0xFFB23A2E),
        StatusKind.echeance => const Color(0xFFC0392B),
      };

  IconData get icon => switch (this) {
        StatusKind.brouillon => Icons.edit_note,
        StatusKind.planifie => Icons.event_upcoming,
        StatusKind.enCours => Icons.pending,
        StatusKind.termine => Icons.task_alt,
        StatusKind.valide => Icons.verified,
        StatusKind.rejete => Icons.cancel,
        StatusKind.echeance => Icons.warning_amber,
      };

  String get label => switch (this) {
        StatusKind.brouillon => 'Brouillon',
        StatusKind.planifie => 'Planifié',
        StatusKind.enCours => 'En cours',
        StatusKind.termine => 'Terminé',
        StatusKind.valide => 'Validé',
        StatusKind.rejete => 'Rejeté',
        StatusKind.echeance => 'Échéance',
      };

  /// Mappe une valeur de statut Firestore (héritée de DEMETER1) vers un StatusKind.
  static StatusKind fromFirestore(String? raw) => switch (raw) {
        'brouillon' => StatusKind.brouillon,
        'planifie' => StatusKind.planifie,
        'en_cours' => StatusKind.enCours,
        'termine' => StatusKind.termine,
        'valide' || 'approuve' => StatusKind.valide,
        'rejete' => StatusKind.rejete,
        _ => StatusKind.brouillon,
      };
}
