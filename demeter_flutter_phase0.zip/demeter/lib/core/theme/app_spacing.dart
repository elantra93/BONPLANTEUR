/// Échelle d'espacement (base 8 pt) et rayons. Voir §3.4 de CLAUDE.md.
abstract final class AppSpacing {
  const AppSpacing._();

  static const double xs = 4;
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 16;
  static const double xl = 24;
  static const double xxl = 32;
  static const double xxxl = 48;
}

abstract final class AppRadius {
  const AppRadius._();

  static const double sm = 8; // champs, cartes
  static const double md = 12; // modales, bottom sheets
  static const double pill = 999; // chips, avatars
}

/// Cible tactile minimale (terrain : doigts, soleil).
abstract final class AppSizes {
  const AppSizes._();

  static const double minTouchTarget = 48;
}
