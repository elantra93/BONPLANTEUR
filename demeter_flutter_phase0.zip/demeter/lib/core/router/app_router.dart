import 'package:go_router/go_router.dart';

import '../../features/showcase/showcase_page.dart';

/// Routeur de l'application.
///
/// 🔒 Non-négociable n°7 (CLAUDE.md) : à partir de la Phase 3, le `redirect`
/// ci-dessous DOIT protéger toutes les routes (auth requise) et appliquer le
/// contrôle de rôle (RBAC). Pour la Phase 0, une seule route de démonstration.
final GoRouter appRouter = GoRouter(
  initialLocation: '/',
  // TODO(Phase 3) : implémenter le redirect d'auth + garde de rôle.
  // redirect: (context, state) { ... return null; },
  routes: [
    GoRoute(
      path: '/',
      name: 'showcase',
      builder: (context, state) => const ShowcasePage(),
    ),
  ],
);
