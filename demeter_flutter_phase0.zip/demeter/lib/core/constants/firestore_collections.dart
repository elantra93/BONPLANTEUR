/// 🔒 SOURCE UNIQUE de tous les noms de collections Firestore.
///
/// Non-négociable n°1 (voir CLAUDE.md) : aucune chaîne de nom de collection
/// ne doit apparaître ailleurs dans le code. On passe TOUJOURS par ces constantes.
///
/// La casse est conservée telle quelle pour rester compatible avec la base de
/// production partagée avec DEMETER1 (ex. `Parcelles`, `Materiels` en PascalCase
/// alors que `exploitations` est en minuscule). C'est volontaire — ne pas « corriger ».
abstract final class FirestoreCollections {
  const FirestoreCollections._();

  static const String users = 'USERS';
  static const String exploitations = 'exploitations';
  static const String parcelles = 'Parcelles'; // PascalCase hérité — ne pas changer
  static const String activites = 'activites';
  static const String depenses = 'depenses';
  static const String collaborateurs = 'collaborateurs';
  static const String stocks = 'stocks';
  static const String consommationStock = 'consommation_stock';
  static const String recoltes = 'recoltes';
  static const String materiels = 'Materiels'; // PascalCase hérité — ne pas changer
  static const String membresExploitation = 'membres_exploitation';
  static const String invitations = 'invitations';
  static const String notifications = 'notifications';
  static const String revenus = 'revenus';
}

/// Noms de champs « tenant » et communs, eux aussi centralisés pour éviter les fautes.
abstract final class FirestoreFields {
  const FirestoreFields._();

  /// 🔒 Champ tenant canonique. TOUTE requête métier filtre dessus.
  static const String exploitationRef = 'exploitation_ref';

  /// 🔒 Drapeau de soft delete. Les listes filtrent is_active == true.
  static const String isActive = 'is_active';

  static const String roles = 'roles';
  static const String datePrevue = 'date_prevue';
  static const String dateExecution = 'date_execution';
  static const String statut = 'statut';
}
