/// Chaînes de marque centralisées (tout en français).
abstract final class AppStrings {
  const AppStrings._();

  static const String appName = 'Demeter';
  static const String tagline = 'Le logiciel métier bâti pour nos champs';
}
