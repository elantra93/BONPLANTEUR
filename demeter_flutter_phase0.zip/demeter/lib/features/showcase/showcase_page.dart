import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app.dart';
import '../../core/constants/app_strings.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../core/theme/status_palette.dart';
import '../../shared/widgets/app_text_field.dart';
import '../../shared/widgets/demeter_logo.dart';
import '../../shared/widgets/primary_button.dart';
import '../../shared/widgets/status_chip.dart';

/// Vitrine du design system (Phase 0). Sert de preuve visuelle de la charte
/// et de référence pour les écrans à venir.
class ShowcasePage extends StatelessWidget {
  const ShowcasePage({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        titleSpacing: AppSpacing.lg,
        title: const DemeterLogo(height: 32),
        actions: [
          IconButton(
            tooltip: isDark ? 'Mode clair' : 'Mode sombre',
            icon: Icon(isDark ? Icons.light_mode : Icons.dark_mode),
            onPressed: () => themeModeNotifier.value =
                isDark ? ThemeMode.light : ThemeMode.dark,
          ),
          const SizedBox(width: AppSpacing.sm),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppSpacing.lg),
        children: [
          Text(AppStrings.tagline, style: theme.textTheme.bodyLarge),
          const SizedBox(height: AppSpacing.xl),

          _Section('Palette de marque', [
            Wrap(
              spacing: AppSpacing.md,
              runSpacing: AppSpacing.md,
              children: const [
                _Swatch('Vert Demeter', AppColors.greenDemeter),
                _Swatch('Brun terre', AppColors.brownEarth),
                _Swatch('Espresso', AppColors.espresso),
                _Swatch('Or blé', AppColors.wheatGold),
              ],
            ),
          ]),

          _Section('Typographie', [
            Text('Demeter', style: theme.textTheme.displayMedium),
            Text('Titre de section', style: theme.textTheme.titleLarge),
            Text(
              'Corps de texte en Inter : lisible au champ comme au bureau.',
              style: theme.textTheme.bodyMedium,
            ),
            const SizedBox(height: AppSpacing.sm),
            Row(
              children: [
                Text('Montant : ', style: theme.textTheme.bodyMedium),
                Text('1 250 000 FCFA',
                    style: AppTypography.money(theme.colorScheme)),
              ],
            ),
          ]),

          _Section('Statuts', [
            Wrap(
              spacing: AppSpacing.sm,
              runSpacing: AppSpacing.sm,
              children: StatusKind.values.map((s) => StatusChip(s)).toList(),
            ),
          ]),

          _Section('Boutons', [
            PrimaryButton(
              label: 'Action principale',
              icon: Icons.add,
              onPressed: () {},
            ),
            const SizedBox(height: AppSpacing.md),
            OutlinedButton(onPressed: () {}, child: const Text('Action secondaire')),
          ]),

          _Section('Saisie', [
            AppTextField(
              label: 'Numéro de téléphone',
              hint: '0700000000',
              helperText: '10 chiffres',
              prefixIcon: Icons.phone,
              keyboardType: TextInputType.phone,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
                LengthLimitingTextInputFormatter(10),
              ],
            ),
            const SizedBox(height: AppSpacing.lg),
            const AppTextField(
              label: 'Mot de passe',
              obscureText: true,
              prefixIcon: Icons.lock_outline,
            ),
          ]),

          const SizedBox(height: AppSpacing.xxl),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  const _Section(this.title, this.children);
  final String title;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.xl),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: theme.textTheme.titleMedium),
          const SizedBox(height: AppSpacing.md),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(AppSpacing.lg),
            decoration: BoxDecoration(
              color: theme.colorScheme.surface,
              borderRadius: BorderRadius.circular(AppRadius.sm),
              border: Border.all(color: theme.colorScheme.outlineVariant),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: children,
            ),
          ),
        ],
      ),
    );
  }
}

class _Swatch extends StatelessWidget {
  const _Swatch(this.name, this.color);
  final String name;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 84,
          height: 56,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(AppRadius.sm),
          ),
        ),
        const SizedBox(height: 6),
        SizedBox(
          width: 84,
          child: Text(name, style: Theme.of(context).textTheme.labelSmall),
        ),
      ],
    );
  }
}
